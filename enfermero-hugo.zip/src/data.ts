export interface Resource {
  id: string;
  title: string;
  description: string;
  category: "profesional" | "cuidador";
  downloadSize: string;
  duration?: string;
  badge: string;
  contentMarkdown: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  imageUrl: string;
  readTime: string;
  author: string;
  content: string;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  imageUrl: string;
  rating: number;
  category: string;
  inStock: boolean;
  features: string[];
}

export const HEALTH_RESOURCES: Resource[] = [
  {
    id: "guia-dosis-iv",
    title: "Guía de Dosificación Intravenosa Crítica",
    description: "Manual rápido de bolsillo con tasas de infusión, diluciones estándar y precauciones para fármacos vasoactivos y cuidados críticos.",
    category: "profesional",
    downloadSize: "1.4 MB",
    duration: "12 págs",
    badge: "Más buscado",
    contentMarkdown: `
# Guía Rápida de Dosificación de Fármacos Intravenosos en Urgencias

Esta guía práctica contiene directrices clínicas resumidas para la administración segura de medicamentos por vía parenteral en unidades de cuidados críticos y de urgencias.

## 1. Fármacos Vasoactivos Comunes
* **Noradrenalina**: Dilución estándar de 4 mg o 8 mg en 250 mL de Glucosa 5%. Administración exclusiva por vía central. Monitoreo constante de tensión arterial.
* **Dobutamina**: Dilución de 250 mg en 250 mL de Suero Fisiológico (SF) o Glucosa 5%. Rango habitual de dosificación: 2.5 a 20 mcg/kg/min.
* **Adrenalina**: En PCR, administración de 1 mg directo directo cada 3-5 minutos. Para soporte hemodinámico, infusión de 0.05 a 0.5 mcg/kg/min.

## 2. Normas de Dilución Comunes
Para evitar flebitis química e incompatibilidades:
1. Respetar siempre el tiempo de infusión indicado (bolo lento, infusión intermitente o continua).
2. Etiquetar perfectamente todas las jeringas de perfusión con: nombre, dosis, volumen, fecha, hora y firma del enfermero.
3. Verificar la compatibilidad física en la Y de administración de las vías.

*Nota:* Esta guía es de carácter docente e informativo y debe ajustarse a los protocolos internos de cada centro de salud.
    `
  },
  {
    id: "protocolo-pcr-2026",
    title: "Protocolo de Soporte Vital Avanzado Act",
    description: "Algoritmos actualizados de actuación inmediata ante parada cardiorrespiratoria, ritmos desfibrilables e intubación de secuencia rápida.",
    category: "profesional",
    downloadSize: "2.8 MB",
    duration: "6 págs",
    badge: "Actualizado 2026",
    contentMarkdown: `
# Protocolo de RCP Avanzada (SVA) - Actualización 2026

Actualizaciones clave para la reanimación cardiopulmonar avanzada intrahospitalaria y extrahospitalaria.

## Algoritmo Simplificado de SVA
1. **Identificación de la PCR**: Comprobar respuesta, ausencia de respiración normal y pulso carotídeo en <10s. Iniciar RCP inmediatamente (30 compresiones, 2 ventilaciones) mientras se conecta el Monitor/Desfibrilador.
2. **Análisis de Ritmo**:
   * **Ritmos Desfibrilables (FV / TV sin pulso)**: Aplicar 1 descarga inmediata (150-200J bifásica). Continuar RCP inmediatamente durante 2 minutos. Administrar Adrenalina (1mg IV) tras la 2ª descarga y Amiodarona (300mg IV) tras la 3ª descarga.
   * **Ritmos NO Desfibrilables (Asistolia / AESP)**: Administrar 1mg de Adrenalina IV/IO de inmediato. Mantener RCP ininterrumpida de calidad durante 2 minutos y buscar causas reversibles (4H y 4T).
3. **Manejo de la Vía Aérea**: Priorizar aporte de oxígeno al 100%. Uso de dispositivos supraglóticos (máscara laríngea) o intubación endotraqueal sólo por personal experto, evitando interrupciones en el masaje cardiaco de más de 10s.
4. **Capnografía Cuantitativa**: Monitorizar para medir la calidad de las compresiones (mantener rETCO2 > 10-15 mmHg) e identificar un Retorno de la Circulación Espontánea (ROSC).
    `
  },
  {
    id: "guia-curas-heridas",
    title: "Tratamiento de Heridas Complejas y Úlceras",
    description: "Criterios basados en la evidencia clínica para la cura en ambiente húmedo, selección de apósitos sofisticados y control de carga bacteriana.",
    category: "profesional",
    downloadSize: "3.2 MB",
    duration: "18 págs",
    badge: "Novedad",
    contentMarkdown: `
# Guía de Práctica Clínica: Manejo Integrado de Heridas Complejas

El tratamiento moderno de las heridas complejas (úlceras por presión, vasculares o pie diabético) prioriza la Cura en Ambiente Húmedo (CAH) bajo un enfoque sistemático (esquema TIME).

## Abordaje TIME (Tejido, Infección/Inflamación, Humedad, Bordes Epiteliales)
* **T - Tejido No Viable**: Desbridamiento (quirúrgico, enzimático, osmótico, autolítico o biológico) para eliminar el lecho esfacelado o necrótico que bloquea la granulación.
* **I - Infección y Control Bacteriano**: Evaluación de biofilmes en heridas estancadas. Uso de apósitos de plata de liberación sostenida, apósitos de DACC o polihexanida (PHMB). Evitar antisépticos locales citotóxicos como la povidona yodada en heridas limpias.
* **M - Control de Humedad (Exudado)**: Equilibrar los fluidos. Apósitos hiperabsorbentes o espumas de poliuretano (hidrocelulares) para exudado moderado-alto. Hidrogeles para aportar humedad en lechos secos.
* **E - Bordes Cutáneos (Edge)**: Proteger la piel perilesional de la maceración aplicando pomadas barrera o película de polímero acrílico sin alcohol.
    `
  },
  {
    id: "manual-primeros-auxilios",
    title: "Manual de Primeros Auxilios en el Hogar",
    description: "Instrucciones de actuación rápida ante quemaduras accidentales, atragantamientos, caídas con sospecha de fractura y RCP básica familiar.",
    category: "cuidador",
    downloadSize: "1.9 MB",
    duration: "25 págs",
    badge: "Imprescindible",
    contentMarkdown: `
# Manual de Primeros Auxilios Esenciales para Cuidadores y Familias

Guía paso a paso sobre cómo resolver situaciones de urgencia médica común en el domicilio antes de la llegada de los servicios sanitarios de emergencia.

## 1. Actuación ante Atragantamiento (Maniobra de Heimlich)
* **Si la persona tose con fuerza**: Animarla a seguir tosiendo. No dar golpes en la espalda ya que podría desplazarse el objeto hacia dentro bloqueando la vía por completo.
* **Si la tos es ineficaz o cesa (Atragantamiento grave)**:
   1. Colocarse al lado y ligeramente detrás del afectado. Inclinarlo hacia delante y dar hasta 5 palmadas interescapulares (en la parte alta de la espalda) firmes con el talón de la mano.
   2. Si no funciona, colocarse detrás, rodear la parte alta de su abdomen con ambos brazos, hacer un puño por encima del ombligo, sujetarlo con la otra mano y realizar hasta 5 presiones abdominales rápidas hacia dentro y arriba (Heimlich).
   3. Si pierde la consciencia, recostar en el suelo e iniciar maniobras de RCP (llamar de inmediato al 112).

## 2. Quemaduras Domésticas
* **Qué HACER**: Enfriar de forma inmediata la zona quemada bajo un chorro suave de agua templada (entre 15 y 20 °C) durante al menos 10-15 minutos. Cubrir la herida de forma holgada con gasa limpia o film transparente humedecido.
* **Qué NO HACER**: Nunca aplicar hielo directo sobre la quemadura. No aplicar pasta de dientes, mantequilla ni pomadas caseras impropias. Jamás pinchar o reventar las ampollas (flictenas), ya que actúan como defensa natural estéril frente a infecciones.
    `
  },
  {
    id: "guia-insulina-segura",
    title: "Pautas de Administración y Conservación de Insulina",
    description: "Métodos seguros para rotar las zonas de inyección, reconocimiento del material, agujas indicadas y prevención de lipodistrofias.",
    category: "cuidador",
    downloadSize: "1.1 MB",
    duration: "8 págs",
    badge: "Didáctico",
    contentMarkdown: `
# Pauta Educativa: Uso Seguro de la Insulina en el Domicilio

Una guía ilustrada orientada a pacientes de diabetes mellitus y cuidadores encargados de la administración diaria de insulina.

## 1. Conservación de la Insulina
* **Insulina en uso**: Se puede mantener perfectamente a temperatura ambiente (menos de 25-30 °C) hasta por un máximo de 28 días. Evite exponerla a la luz solar directa o a fuentes de calor intensas.
* **Plumas de reserva**: Deben almacenarse en el frigorífico común (entre 2 y 8 °C). Evite depositarlas en la zona posterior o en el congelador, ya que si la insulina llega a congelarse, pierde sus propiedades por completo y debe desecharse.

## 2. Técnica de Inyección y Rotación
* **Zonas de Inyección**: Abdomen (respetando un radio de 4 cm alrededor del ombligo), cuadrante superoexterno de los muslos, parte posterior de los brazos y glúteos.
* **Rotación sistemática**: Es fundamental cambiar el punto específico de inyección en cada toma para evitar la aparición de lipodistrofias (endurecimientos bajo la piel que alteran drásticamente la velocidad de absorción hormonal).
* **Agujas**: Use tamaños cortos certificados (4 mm o 5 mm) para asegurar una inyección subcutánea limpia y sin dolor, evitando pinchar en el músculo. No reutilice nunca las agujas de un solo uso.
    `
  },
  {
    id: "manual-paciente-encamado",
    title: "Manual Práctico de Cuidado de Pacientes Encamados",
    description: "Técnicas ergonómicas de movilización segura, higiene total en cama, nutrición adaptada y prevención activa de úlceras por presión.",
    category: "cuidador",
    downloadSize: "2.1 MB",
    duration: "14 págs",
    badge: "Muy recomendado",
    contentMarkdown: `
# Manual de Cuidado Corporal para el Paciente Encamado en el Domicilio

Guía orientada a familiares para garantizar el máximo confort físico de personas en situación de dependencia o inmovilidad prolongada.

## 1. Prevención Efectiva de Úlceras por Presión (UPP)
Las personas que permanecen inmóviles ejercen presión constante en puntos óseos específicos (talones, sacro, codos, occipital) interrumpiendo el flujo circulatorio de la piel.
* **Cambios Posturales**: Realizar rotaciones cada 2 a 3 horas siguiendo un ciclo sistemático (boca arriba, de lado izquierdo, de lado derecho).
* **Protección del Sacro y Talones**: Empleo de taloneras protectoras. Mantener las sábanas de la cama totalmente estiradas, secas y completamente libres de arrugas o migas de alimentos.
* **Hidratación de la Piel**: Aplicar ácidos grasos hiperoxigenados (AGHO) sobre zonas de presión prominentes realizando masajes periféricos ultra-suaves (nunca frotar la zona central enrojecida).

## 2. Higiene del Paciente Encamado
* Realizar el baño empleando agua templada y esponjas con jabón neutro, dividiendo el cuerpo por zonas. Se debe secar a golpecitos con una toalla suave, sin frotar. Especial atención a los pliegues cutáneos (axilas, ingles, debajo de las mamas) para evitar la humedad local y la maceración.
    `
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: "mitos-vacunacion-2026",
    title: "Mitos de la vacunación a examen: Evidencia científica",
    excerpt: "Analizamos de forma objetiva y basada en estudios recientes los falsos mitos que circulan en redes sobre las vacunas sistemáticas y de nueva generación.",
    category: "Divulgación Científica",
    date: "14 May 2026",
    imageUrl: "https://images.unsplash.com/photo-1618961734760-466979cb35b0?auto=format&fit=crop&w=600&q=80",
    readTime: "6 min de lectura",
    author: "Enfermero Hugo",
    content: `
Las vacunas representan uno de los mayores logros de la salud pública mundial en los últimos siglos, salvando millones de vidas anualmente. No obstante, la rápida proliferación de desinformación digital ha impulsado un resurgimiento de mitos pseudocientíficos. En este artículo analizamos objetivamente las dudas más recurrentes.

### Mito 1: 'Contienen ingredientes altamente tóxicos'
El extendido temor al tiomersal (mercurio), formaldehído o sales de aluminio carece de fundamento biológico con las dosis utilizadas. Por ejemplo, el formaldehído se produce de forma natural en el metabolismo del cuerpo humano a niveles muy superiores a los de cualquier vial de vacuna. Las cantidades de aluminio actúan como adyuvante para estimular una respuesta inmunitaria robusta y son ínfimas en comparación con el aluminio ingerido diariamente a través del agua potable y los alimentos cotidianos.

### Mito 2: 'Inmunizarse de forma natural es más seguro'
Quienes defienden contraer la enfermedad vírica (como el sarampión o la varicela) de forma directa ignoran de manera temeraria las secuelas severas asociadas. Una neumonía grave, encefalitis de pronóstico nefasto o cardiopatías coronarias son desenlaces reales para patologías infantiles prevenibles por vacunación. Las vacunas estimulan de manera controlada al sistema inmunitario sin exponer al paciente al terrible daño multiorgánico de la infección real.

### Mito 3: 'Sobrecargan el sistema inmunológico infantil'
Desde el nacimiento, un bebé interactúa dinámicamente con miles de gérmenes bacterianos y alérgenos en el aire y la piel. Las vacunas del calendario oficial apenas representan una mínima fracción (menos del 0.1%) de la capacidad de respuesta de los linfocitos infantiles.

**Conclusión:**
La inmunidad colectiva o 'de rebaño' protege de forma solidaria a individuos vulnerables que no pueden vacunarse debido a discrasias sanguíneas o inmunosupresiones graves. La vacunación es un acto de responsabilidad colectiva basado en ciencia rigurosa.
    `
  },
  {
    id: "colapso-primaria-debate",
    title: "El colapso de la atención primaria: Soluciones desde la Enfermería",
    excerpt: "Un debate constructivo sobre los cuellos de botella en el sistema público y cómo reforzar las competencias enfermeras puede agilizar las consultas.",
    category: "Gestión Sanitaria",
    date: "02 Jun 2026",
    imageUrl: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=600&q=80",
    readTime: "8 min de lectura",
    author: "Enfermero Hugo",
    content: `
La saturación de los centros de salud es un hecho palpable. Las listas de espera para una consulta no urgente superan con frecuencia la semana, trasladando la urgencia asistencial a las colapsadas salas de Urgencia Hospitalaria. Una de las soluciones más viables reside en expandir el ámbito de responsabilidad y potenciar el liderazgo de la Enfermería Familiar y Comunitaria.

### 1. La Consulta de Gestión de la Demanda por Enfermería
Muchos de los motivos de consulta diaria en atención primaria corresponden a autocuidados, curas complejas, vacunaciones, dudas de adherencia de medicación crónica y procesos autolimitados de carácter leve (resfriados comunes, diarrea transitoria). Cuando se implementan protocolos de cribado específicos y consultas de gestión de la demanda lideradas por enfermería, se resuelve con alta satisfacción hasta el 60% de estos episodios sin saturar la agenda médica de los facultativos.

### 2. Prescripción Enfermera Independiente y Colaborativa
La habilitación para indicar, usar y autorizar la dispensación de medicamentos no sujetos a receta médica, y de aquellos sujetos a prescripción mediante protocolos específicos (como vacunas, insulinas, absorbentes de incontinencia o apósitos avanzados), optimiza drásticamente los tiempos de atención del paciente, reduciendo las visitas duplicadas de carácter burocrático.

### 3. Educación grupal: El paciente experto
Los talleres para controlar de manera autónoma la hipertensión arterial, asma domiciliaria o monitorización glucémica capacitan a los pacientes crónicos facilitando que conozcan sus signos de alarma, limitando enormemente las descompensaciones que requieren uso de recursos hospitalarios urgentes.

**Reflexión:**
Aprovechar al máximo el potencial formativo y clínico de los enfermeros no es una invasión de competencias; es una reestructuración de sentido común y de optimización de recursos sanitarios para salvaguardar la excelencia de la sanidad pública.
    `
  },
  {
    id: "reanimacion-cardiopulmonar-pautas",
    title: "Reanimación Cardiopulmonar: Pautas vitales para la comunidad",
    excerpt: "Familiarizarnos con el masaje cardiaco básico en entornos cotidianos y el uso sin miedo de desfibriladores automáticos externos (DESA).",
    category: "Primeros Auxilios",
    date: "28 Abr 2026",
    imageUrl: "https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&w=600&q=80",
    readTime: "5 min de lectura",
    author: "Enfermero Hugo",
    content: `
Aproximadamente el 80% de las paradas cardiacas ocurren fuera de los hospitales, principalmente en hogares, oficinas, estadios o de forma súbita en la vía pública. Los primeros 4 minutos del evento son determinantes para evitar daños neurológicos irreversibles. Aprender a efectuar compresiones torácicas efectivas de manera inmediata duplica y hasta triplica las probabilidades de supervivencia.

### ¿Cómo actuar ante una pérdida de conocimiento imprevista?
Para actuar de forma decidida y sistemática ante una emergencia, emplee la metodología unificada:

1. **Asegurar la Zona (PAS - Proteger, Avisar, Socorrer)**: Cerciorarse de que tanto usted como la víctima y los pacientes cercanos están libres de peligros inmediatos (tráfico, cables sueltos, incendios).
2. **Evaluar Respuesta**: Agitar suavemente por los hombros al afectado y preguntarle en voz alta: *"¿Se encuentra bien?"*
3. **Comprobar Respiración (Maniobra Frente-Mentón)**: Colocar una mano sobre la frente del individuo y los dedos de la otra bajo la barbilla, inclinando suavemente su cabeza hacia atrás. Acerque su oreja a la boca del paciente mirando su pecho para: **Ver** si se mueve el pecho, **Oír** el paso de aire y **Sentir** el aire espirado en su mejilla (realice esto durante un tiempo de 10 segundos).
4. **Si NO RESPIRA o respira de forma ineficaz (boqueos)**: Llame inmediatamente al Teléfono de Emergencias 112, poniendo el manos libres de su móvil. Inicie RCP de forma inmediata.

### El Masaje Cardiaco
* Coloque el talón de una mano en el centro del pecho de la víctima (mitad inferior del esternón) y la otra mano entrelazada sobre la primera.
* Con los brazos totalmente estirados en vertical y los hombros alineados justo sobre sus manos, deje caer su peso para hundir el esternón entre 5 y 6 centímetros.
* Aplique compresiones a una velocidad rítmica constante de entre 100 y 120 latidos por minuto (siga el ritmo mental de la canción *'Stayin' Alive'* de los Bee Gees). Deje que el pecho retorne a su posición natural tras cada compresión sin despegar las manos del tórax.

### El Desfibrilador Semiautomático (DESA)
Hoy en día abundan los desfibriladores en estaciones, comercios grandes o pabellones deportivos. Son de manipulación intuitiva y totalmente seguros: una voz grabada detalla paso por paso qué hacer tras pulsar el botón de encendido. El aparato analiza de forma autónoma el ritmo eléctrico cardiaco y **sólo aplicará o aconsejará descarga si es necesario**, impidiendo accidentes involuntarios. ¡No tenga miedo de usarlo, salva vidas!
    `
  }
];

export const PRODUCTS: Product[] = [
  {
    id: "prod-littmann-classic",
    title: "Estetoscopio Premium Littmann Classic III",
    description: "Estetoscopio acústico de alta sensibilidad acústica y de diseño elegante en azul sanitario profundo. Membrana de doble cara fácil de limpiar y resistente a grasas de la piel.",
    price: 114.95,
    imageUrl: "https://images.unsplash.com/photo-1615486511487-12f377cc4a56?auto=format&fit=crop&w=600&q=80",
    rating: 4.9,
    category: "Instrumental",
    inStock: true,
    features: [
      "Acústica excepcional para exploración general, cardíaca y pulmonar",
      "Membrana de doble pieza fácil de instalar en caras de adultos y niños",
      "Tubo de última generación resistente a alcoholes y aceites corporales",
      "Olivas blandas con sellado hermético ultra-confortable"
    ]
  },
  {
    id: "prod-pocket-organizer",
    title: "Organizador de Bolsillo Multiusos 'Salvapiernas'",
    description: "Espacioso organizador de silicona lavable, diseñado meticulosamente para encajar en el bolsillo del uniforme. Evita pinchazos accidentales y mantiene los bolis, tijeras y esparadrapo en perfecto orden.",
    price: 14.90,
    imageUrl: "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=600&q=80",
    rating: 4.7,
    category: "Organización",
    inStock: true,
    features: [
      "Material de silicona gomosa flexible antideslizante",
      "3 bolsillos frontales rápidos, ranura para pinzas y clip metálico",
      "Desmontable e impermeable para lavado desinfectante instantáneo",
      "Imán integrado para fijación estable en solapas o bata"
    ]
  },
  {
    id: "prod-nurse-taza",
    title: "Taza de Cerámica 'Cuidado con Base Científica'",
    description: "Preciosa taza cerámica blanca con diseño minimalista en azul marino profundo. Inspiración diaria y motivadora para los cafés o infusiones previas a los duros turnos de 12 horas.",
    price: 12.50,
    imageUrl: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80",
    rating: 4.8,
    category: "Merchandising",
    inStock: true,
    features: [
      "Cerámica vitrificada de calidad extra resistente al microondas",
      "Impresión de alta resolución apta para lavavajillas industrial",
      "Capacidad de 350 mL perfecta para café americano o té grande",
      "Diseñada e ilustrada de forma exclusiva por @elenfermerohugo"
    ]
  },
  {
    id: "prod-calcetines-compresion",
    title: "Calcetines de Compresión Graduada 'Doce Horas'",
    description: "Calcetines de compresión progresiva media (15-21 mmHg) diseñados con fibras de bambú transpirables. Ideales para aliviar piernas cansadas y prevenir varices durante las guardias más demandantes.",
    price: 19.95,
    imageUrl: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=600&q=80",
    rating: 4.9,
    category: "Uniformidad",
    inStock: true,
    features: [
      "Hilos de fibra ecológica de bambú hipoalergénica con control de olores",
      "Compresión media gradual recomendada para bipedestación prolongada",
      "Soporte acolchado extra en talones, arco plantar y tendón de Aquiles",
      "Costura extra plana para evitar ampollas o rozaduras molestas"
    ]
  }
];

export const INSTAGRAM_FEED_PREVIEW = {
  handle: "@elenfermerohugo",
  followers: "48.6K",
  postsCount: "342",
  profileUrl: "https://instagram.com/elenfermerohugo",
  posts: [
    {
      id: "ig-1",
      likes: "1,245",
      comments: "148",
      imageUrl: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=400&q=80",
      caption: "¡Hoy hablamos de las vacunas! Desmintiendo falsos mitos con evidencia y de forma muy clara. 💉🧬 #enfermeria #vacunas"
    },
    {
      id: "ig-2",
      likes: "982",
      comments: "76",
      imageUrl: "https://images.unsplash.com/photo-1584030373081-f37b7bb4fa8e?auto=format&fit=crop&w=400&q=80",
      caption: "Lavar de manera óptima las heridas en casa es clave. Te dejo las directrices cruciales para evitar infectarlas. 🩹🧼 #salud #primerosauxilios"
    },
    {
      id: "ig-3",
      likes: "2,104",
      comments: "215",
      imageUrl: "https://images.unsplash.com/photo-1579684389782-64d84b5e902a?auto=format&fit=crop&w=400&q=80",
      caption: "Prescripción enfermera: ¿qué podemos indicar de manera autónoma actualmente? Te lo explico fácil. 🩺📑 #sanidad #enfermero"
    }
  ]
};
