import { useState, useEffect } from "react";
import { 
  Stethoscope, 
  HeartPulse, 
  Smartphone, 
  BookOpen, 
  Download, 
  ShoppingBag, 
  ArrowRight, 
  Check, 
  Star, 
  X, 
  Menu, 
  Instagram, 
  Heart, 
  MessageCircle, 
  FileText, 
  Plus, 
  Minus, 
  Trash2, 
  User, 
  Clock, 
  ArrowLeft, 
  Send, 
  Sparkles, 
  ShieldCheck, 
  Calculator, 
  ChevronRight,
  Share2,
  Activity,
  Mail
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  HEALTH_RESOURCES, 
  BLOG_POSTS, 
  PRODUCTS, 
  INSTAGRAM_FEED_PREVIEW, 
  Resource, 
  BlogPost, 
  Product 
} from "./data";

export default function App() {
  // Mobile menu state
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Tab filtered state for Resources
  const [activeResourceCategory, setActiveResourceCategory] = useState<"todos" | "profesional" | "cuidador">("todos");
  
  // Shopping Cart state
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  
  // Modal / Drawer reading state
  const [selectedResource, setSelectedResource] = useState<Resource | null>(null);
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Interactive PWA mock emulator states
  const [pwaActiveTab, setPwaActiveTab] = useState<"goteo" | "wallace" | "pautas">("goteo");
  const [pwaInstallModal, setPwaInstallModal] = useState<"ios" | "android" | null>(null);
  
  // Drip calculator state
  const [dripVolume, setDripVolume] = useState<number>(500);
  const [dripHours, setDripHours] = useState<number>(8);
  
  // Wallace rule state
  const [wallaceSelected, setWallaceSelected] = useState<Record<string, boolean>>({
    cabeza: false,
    troncoAnt: false,
    troncoPost: false,
    brazoIzq: false,
    brazoDer: false,
    piernaIzq: false,
    piernaDer: false,
    genitales: false
  });

  // Newsletter notification
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  // Quick info alert bar state
  const [activeNotification, setActiveNotification] = useState<string | null>(
    "🔥 Nueva actualización: Guía de Soporte Vital Avanzado 2026 ya disponible para descarga gratuita."
  );

  // Cart helper functions
  const addToCart = (product: Product) => {
    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.product.id === product.id);
      if (existing) {
        return prevCart.map((item) => 
          item.product.id === product.id 
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevCart, { product, quantity: 1 }];
    });
    // Open cart sidebar automatically to provide premium visual feedback
    setCartOpen(true);
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart((prevCart) => {
      return prevCart
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return { ...item, quantity: newQty };
          }
          return item;
        })
        .filter((item) => item.quantity > 0);
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.product.id !== productId));
  };

  const cartTotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const cartItemCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Wallace surface calculator
  const calculateTBSA = () => {
    let tbsa = 0;
    if (wallaceSelected.cabeza) tbsa += 9;
    if (wallaceSelected.troncoAnt) tbsa += 18;
    if (wallaceSelected.troncoPost) tbsa += 18;
    if (wallaceSelected.brazoIzq) tbsa += 9;
    if (wallaceSelected.brazoDer) tbsa += 9;
    if (wallaceSelected.piernaIzq) tbsa += 18;
    if (wallaceSelected.piernaDer) tbsa += 18;
    if (wallaceSelected.genitales) tbsa += 1;
    return tbsa;
  };

  const getParklandVolume = (weightKg = 70) => {
    const tbsa = calculateTBSA();
    return 4 * weightKg * tbsa; // Parkland formula: 4ml x kg x %TBSA over 24h
  };

  // Resources filter
  const filteredResources = HEALTH_RESOURCES.filter(r => {
    if (activeResourceCategory === "todos") return true;
    return r.category === activeResourceCategory;
  });

  return (
    <div className="min-h-screen bg-slate-50/40 text-slate-900 font-sans antialiased selection:bg-sky-100 selection:text-sky-900">
      
      {/* Dynamic top notification banner */}
      {activeNotification && (
        <div id="top-banner" className="bg-sky-950 text-white py-2 px-4 text-xs font-medium text-center relative flex items-center justify-center gap-2 animate-fade-in">
          <Sparkles className="w-3 px-0 h-3 text-sky-400 shrink-0" />
          <span>{activeNotification}</span>
          <button 
            onClick={() => setActiveNotification(null)}
            className="absolute right-3 top-2 text-sky-300 hover:text-white transition-colors"
            title="Cerrar aviso"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* HEADER & NAVIGATION */}
      <header id="main-header" className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-100/80 transition-shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          
          {/* Logo brand */}
          <a href="#inicio" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-xl bg-sky-600/10 flex items-center justify-center text-sky-600 group-hover:bg-sky-600 group-hover:text-white transition-all duration-300">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div>
              <span className="font-display font-extrabold text-lg text-slate-950 block tracking-tight leading-tight">
                Enfermero Hugo
              </span>
              <span className="text-[10px] font-mono tracking-widest text-sky-600 uppercase leading-none block font-medium">
                Divulgación & Ciencia
              </span>
            </div>
          </a>

          {/* Large Screen Navigation Menu */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#inicio" className="text-sm font-medium text-slate-600 hover:text-sky-600 transition-colors">Inicio</a>
            <a href="#recursos" className="text-sm font-medium text-slate-600 hover:text-sky-600 transition-colors">Recursos</a>
            <a href="#pwa" className="text-sm font-medium text-slate-600 hover:text-sky-600 transition-colors">La PWA</a>
            <a href="#blog" className="text-sm font-medium text-slate-600 hover:text-sky-600 transition-colors">Debate & Blog</a>
            <a href="#tienda" className="text-sm font-medium text-slate-600 hover:text-sky-600 transition-colors">Tienda</a>
            <a href="#comunidad" className="text-sm font-medium text-slate-600 hover:text-sky-600 transition-colors">Comunidad IG</a>
          </nav>

          {/* Navigation Action Buttons Group */}
          <div className="flex items-center gap-3">
            {/* Direct Instagram Link */}
            <a 
              href="https://instagram.com/elenfermerohugo" 
              target="_blank" 
              className="text-slate-500 hover:text-sky-600 hover:bg-slate-50 p-2 rounded-lg transition-all hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold"
              title="Ir a Instagram"
            >
              <Instagram className="w-4 h-4 text-pink-500" />
              <span>@elenfermerohugo</span>
            </a>

            {/* In-app cart status trigger */}
            <button
              onClick={() => setCartOpen(true)}
              className="relative p-2.5 rounded-xl border border-slate-100 hover:border-sky-100 hover:bg-sky-50 text-slate-700 hover:text-sky-700 transition-all"
              aria-label="Ver carrito de compras"
              id="cart-trigger"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center animate-pulse">
                  {cartItemCount}
                </span>
              )}
            </button>

            {/* Quick action button */}
            <a 
              href="#pwa"
              className="hidden lg:inline-flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition-all shadow-sm"
              id="header-pwa-cta"
            >
              <Smartphone className="w-4 h-4 text-sky-400" />
              <span>Acceder PWA</span>
            </a>

            {/* Mobile menu hamburger toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2.5 rounded-xl border border-slate-100 hover:bg-slate-50 text-slate-700 transition"
              aria-label="Abrir menú"
              id="mobile-menu-toggle"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>

        </div>
      </header>

      {/* Mobile navigation side drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            {/* Backdrop cover */}
            <div 
              className="fixed inset-0 z-40 bg-slate-950/20 backdrop-blur-xs"
              onClick={() => setMobileMenuOpen(false)}
            />
            {/* Drawer sheet */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", bounce: 0, duration: 0.4 }}
              className="fixed right-0 top-0 bottom-0 z-50 w-80 bg-white shadow-2xl p-6 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between pb-6 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Stethoscope className="w-5 h-5 text-sky-600" />
                    <span className="font-display font-extrabold text-slate-900 text-md">Hugo Enfermero</span>
                  </div>
                  <button 
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-2 -mr-2 rounded-lg hover:bg-slate-50 text-slate-400 hover:text-slate-900 transition"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="py-6 flex flex-col gap-4">
                  <a 
                    href="#inicio" 
                    className="text-base font-semibold text-slate-800 hover:text-sky-600 py-1.5"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Inicio
                  </a>
                  <a 
                    href="#recursos" 
                    className="text-base font-semibold text-slate-800 hover:text-sky-600 py-1.5"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Recursos Clínicos
                  </a>
                  <a 
                    href="#pwa" 
                    className="text-base font-semibold text-slate-800 hover:text-sky-600 py-1.5"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Herramientas PWA
                  </a>
                  <a 
                    href="#blog" 
                    className="text-base font-semibold text-slate-800 hover:text-sky-600 py-1.5"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Debate Científico
                  </a>
                  <a 
                    href="#tienda" 
                    className="text-base font-semibold text-slate-800 hover:text-sky-600 py-1.5"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Tienda de Enfermería
                  </a>
                  <a 
                    href="#comunidad" 
                    className="text-base font-semibold text-slate-800 hover:text-sky-600 py-1.5"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Comunidad @elenfermerohugo
                  </a>
                </div>
              </div>

              <div className="border-t border-slate-100 pt-6">
                <a 
                  href="https://instagram.com/elenfermerohugo" 
                  target="_blank"
                  className="w-full flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-medium text-sm py-3 rounded-xl transition"
                >
                  <Instagram className="w-4 h-4" />
                  <span>Seguir en Instagram</span>
                </a>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>


      {/* HERO SECTION / INICIO */}
      <section id="inicio" className="relative pt-10 pb-16 lg:py-24 bg-gradient-to-b from-sky-50/50 via-white to-white overflow-hidden">
        
        {/* Abstract vector clean blurs */}
        <div className="absolute top-20 right-0 -mr-40 w-96 h-96 bg-cyan-100/40 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-60 left-0 -ml-40 w-96 h-96 bg-sky-100/30 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            
            {/* Left Column Text & Misión */}
            <div className="lg:col-span-7 flex flex-col items-start text-left">
              
              <div className="inline-flex items-center gap-1.5 bg-sky-50 text-sky-700 text-xs font-semibold px-3 py-1 rounded-full mb-6 border border-sky-100/60">
                <HeartPulse className="w-3.5 h-3.5" />
                <span>Salud y Cuidados de Base Científica</span>
              </div>

              <h1 className="font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl text-slate-900 tracking-tight leading-[1.1] mb-6">
                Ciencia en el bolsillo,<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-600 to-cyan-500">
                  empatía en el cuidado.
                </span>
              </h1>

              <p className="text-md sm:text-lg text-slate-600 leading-relaxed max-w-xl mb-8">
                Soy <strong>Hugo</strong>, enfermero clínico y divulgador de salud. A través de este portal y de mi cuenta <a href="https://instagram.com/elenfermerohugo" target="_blank" className="text-sky-600 font-bold hover:underline">@elenfermerohugo</a>, acerco la evidencia científica a profesionales sanitarios, estudiantes y familias, traduciendo directrices complejas en pautas accesibles y seguras.
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto">
                <a 
                  href="#recursos" 
                  className="w-full sm:w-auto text-center bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm px-7 py-4 rounded-2xl shadow-lg shadow-sky-600/10 transition-all hover:-translate-y-0.5 justify-center inline-flex items-center gap-2"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Ver Recursos Gratuitos</span>
                </a>
                <a 
                  href="#pwa" 
                  className="w-full sm:w-auto text-center bg-white hover:bg-slate-50 text-slate-800 font-semibold text-sm px-7 py-4 rounded-2xl border border-slate-200 transition-all hover:border-slate-300 justify-center inline-flex items-center gap-2"
                >
                  <Smartphone className="w-4 h-4 text-sky-500" />
                  <span>Acceder Herramientas PWA</span>
                </a>
              </div>

              {/* Direct Trust Credentials Indicator */}
              <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 border-t border-slate-100 pt-8 w-full">
                <div>
                  <span className="font-display font-extrabold text-2xl text-slate-950 block">48.6K+</span>
                  <span className="text-xs text-slate-500">Lectores y Sanitarios de Comunidad</span>
                </div>
                <div>
                  <span className="font-display font-extrabold text-2xl text-slate-950 block">100%</span>
                  <span className="text-xs text-slate-500">Evidencia avalada científicamente</span>
                </div>
                <div>
                  <span className="font-display font-extrabold text-2xl text-slate-950 block">6+</span>
                  <span className="text-xs text-slate-500">Protocolos clínicos interactivos</span>
                </div>
              </div>

            </div>

            {/* Right Column Hugo Stock Profile Photo Container */}
            <div className="lg:col-span-5 flex justify-center lg:justify-end">
              <div className="relative">
                
                {/* Visual back frame */}
                <div className="absolute inset-0 bg-sky-500/10 rounded-full translate-x-3 translate-y-3 -z-10" style={{ width: "350px", height: "350px" }} />
                
                {/* Hugo Profile Image Wrapper */}
                <div 
                  className="profile-container relative border-4 border-white bg-slate-100 overflow-hidden" 
                  style={{ 
                    width: "350px", 
                    height: "350px", 
                    borderRadius: "50%", 
                    boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1)" 
                  }}
                >
                  <img 
                    src="IMG_9876 (1).jpg" 
                    alt="Enfermero Hugo" 
                    style={{ 
                      width: "100%", 
                      height: "100%", 
                      objectFit: "cover", 
                      objectPosition: "center 22%", 
                      filter: "brightness(1.15) contrast(1.05)" 
                    }}
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Ambient medical widget design elements (Floating badges) */}
                <span className="absolute -top-3 -left-3 animate-bounce shadow-md bg-white p-3 rounded-2xl border border-slate-100 text-sky-600 block z-10">
                  <Heart className="w-5 h-5 fill-red-500 text-red-500" />
                </span>

                {/* Floating Badge representing the active badge */}
                <div className="absolute -bottom-2 -right-4 bg-white/95 backdrop-blur-md p-3.5 rounded-2xl shadow-xl border border-slate-100 flex items-center gap-3 z-10 max-w-xs">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-slate-950 leading-none">Colegiado Activo</p>
                    <p className="text-[10px] text-slate-500 leading-tight mt-1">Especialista en Cuidados Generales y Críticos</p>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>


      {/* SECTION PWA (PROGRESSIVE WEB APP) */}
      <section id="pwa" className="py-20 lg:py-28 bg-[#EBF4F6] border-t border-b border-sky-100/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section title, center aligned */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold tracking-widest text-sky-600 uppercase">La PWA en tu mano</span>
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 mt-2 tracking-tight">
              Herramientas Clínicas del Enfermero Hugo
            </h2>
            <p className="text-md text-slate-600 mt-4 leading-relaxed">
              He programado esta aplicación web progresiva para darte acceso instantáneo a calculadoras fisiológicas y algoritmos, incluso sin conexión a internet en la planta. Instálala en tu móvil en segundos.
            </p>
          </div>

          <div className="grid lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column explaining perks */}
            <div className="lg:col-span-6 flex flex-col justify-center">
              <h3 className="font-display font-bold text-2xl text-slate-950 leading-snug mb-6">
                ¿Qué incluye la PWA para tu práctica diaria?
              </h3>

              <div className="space-y-6">
                
                {/* Perk 1 */}
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shrink-0 shadow-sm text-sky-600">
                    <Calculator className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-950 text-sm">Calculadoras de Infusión en Tiempo Real</h4>
                    <p className="text-xs text-slate-600 mt-1 leading-normal">
                      Evita cálculos manuales tediosos. Calcula goteos, microgoteos e infusiones de fármacos de manera inequívoca en segundos.
                    </p>
                  </div>
                </div>

                {/* Perk 2 */}
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shrink-0 shadow-sm text-sky-600">
                    <Activity className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-950 text-sm">Regla de Wallace para Quemaduras</h4>
                    <p className="text-xs text-slate-600 mt-1 leading-normal">
                      Cómputo instantáneo de la superficie corporal quemada (SCTQ) y requerimiento hídrico por la fórmula de Parkland.
                    </p>
                  </div>
                </div>

                {/* Perk 3 */}
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shrink-0 shadow-sm text-sky-600">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-950 text-sm">Soporte Offline Garantizado</h4>
                    <p className="text-xs text-slate-600 mt-1 leading-normal">
                      Funciona perfectamente dentro de ascensores de hospitales o pasillos interiores donde se pierde la señal móvil.
                    </p>
                  </div>
                </div>

              </div>

              {/* Install PWA trigger buttons container */}
              <div className="mt-10 p-5 rounded-2xl bg-white/60 border border-white flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h5 className="font-bold text-xs text-slate-950">¿Listo para llevarla contigo?</h5>
                  <p className="text-[11px] text-slate-500 mt-0.5">Compatible con teléfonos Apple iOS, iPadOS y Android.</p>
                </div>
                <div className="flex gap-2 w-full sm:w-auto shrink-0">
                  <button
                    onClick={() => setPwaInstallModal("ios")}
                    className="flex-1 sm:flex-initial bg-slate-950 text-white font-medium text-xs px-4 py-2.5 rounded-lg hover:bg-slate-800 transition"
                  >
                    Instalar en iOS
                  </button>
                  <button
                    onClick={() => setPwaInstallModal("android")}
                    className="flex-1 sm:flex-initial bg-sky-600 text-white font-medium text-xs px-4 py-2.5 rounded-lg hover:bg-sky-500 transition"
                  >
                    Instalar en Android
                  </button>
                </div>
              </div>

            </div>

            {/* Right Column: Dynamic CSS Smartphone Mockup with active interactive applications to showcase craftsmanship */}
            <div className="lg:col-span-6 flex justify-center">
              <div className="relative w-80 h-[560px] bg-slate-900 rounded-[3rem] p-4 shadow-2xl border-4 border-slate-800/80 ring-12 ring-slate-900/10">
                
                {/* Speaker top notch */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-5 bg-slate-900 rounded-b-xl flex items-center justify-center z-20">
                  <div className="w-12 h-1 bg-slate-800 rounded-full mb-1" />
                </div>

                {/* Inner Screen Layout Container */}
                <div className="w-full h-full bg-white rounded-[2.2rem] overflow-hidden flex flex-col justify-between relative border border-slate-950/5">
                  
                  {/* Phone Header App Bar */}
                  <div className="bg-sky-600/90 text-white pt-6 pb-3 px-4 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 pt-1">
                      <Stethoscope className="w-4 h-4 text-sky-200" />
                      <span className="font-display font-extrabold text-xs tracking-tight">Hugo PWA v2.6</span>
                    </div>
                    <div className="flex items-center gap-2 pt-1">
                      <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
                      <span className="text-[9px] font-mono font-medium tracking-wider text-sky-100 uppercase">ONLINE</span>
                    </div>
                  </div>

                  {/* Tiny Interactive Nav inside Phone */}
                  <div className="bg-slate-50 border-b border-slate-100 grid grid-cols-3 text-center py-2 px-1 text-[11px] font-medium text-slate-500">
                    <button 
                      onClick={() => setPwaActiveTab("goteo")}
                      className={`pb-1.5 ${pwaActiveTab === "goteo" ? "text-sky-600 border-b border-sky-600 font-bold" : "hover:text-slate-900"}`}
                    >
                      🧪 Goteo
                    </button>
                    <button 
                      onClick={() => setPwaActiveTab("wallace")}
                      className={`pb-1.5 ${pwaActiveTab === "wallace" ? "text-sky-600 border-b border-sky-600 font-bold" : "hover:text-slate-900"}`}
                    >
                      🔥 Wallace
                    </button>
                    <button 
                      onClick={() => setPwaActiveTab("pautas")}
                      className={`pb-1.5 ${pwaActiveTab === "pautas" ? "text-sky-600 border-b border-sky-600 font-bold" : "hover:text-slate-900"}`}
                    >
                      🩺 Atajos
                    </button>
                  </div>

                  {/* Active Tool Screen Inside Phone */}
                  <div className="flex-1 overflow-y-auto p-4 bg-slate-50/50">

                    {/* Tool 1: Drip Calculator */}
                    {pwaActiveTab === "goteo" && (
                      <div className="space-y-4">
                        <div className="bg-white p-3.5 rounded-xl border border-slate-100 shadow-sm">
                          <label className="text-[10px] text-slate-500 font-mono block uppercase">Volumen a Administrar</label>
                          <div className="flex items-center justify-between mt-1">
                            <span className="font-display font-extrabold text-base text-slate-950">{dripVolume} mL</span>
                            <div className="flex gap-1.5">
                              <button 
                                onClick={() => setDripVolume(v => Math.max(50, v - 50))} 
                                className="w-7 h-7 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center text-xs font-bold"
                              >
                                -
                              </button>
                              <button 
                                onClick={() => setDripVolume(v => Math.min(2000, v + 50))}
                                className="w-7 h-7 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center text-xs font-bold"
                              >
                                +
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="bg-white p-3.5 rounded-xl border border-slate-100 shadow-sm">
                          <label className="text-[10px] text-slate-500 font-mono block uppercase">Tiempo de Infusión</label>
                          <div className="flex items-center justify-between mt-1">
                            <span className="font-display font-extrabold text-base text-slate-950">{dripHours} Horas</span>
                            <div className="flex gap-1.5">
                              <button 
                                onClick={() => setDripHours(h => Math.max(1, h - 1))} 
                                className="w-7 h-7 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center text-xs font-bold"
                              >
                                -
                              </button>
                              <button 
                                onClick={() => setDripHours(h => Math.min(24, h + 1))}
                                className="w-7 h-7 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center text-xs font-bold"
                              >
                                +
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Calculated Live Outputs */}
                        <div className="bg-sky-600 text-white p-3.5 rounded-xl text-center shadow-md space-y-1.5">
                          <div>
                            <span className="text-[9px] font-mono font-medium uppercase tracking-wider text-sky-200 block">GOTAS POR MINUTO</span>
                            <span className="font-display font-extrabold text-xl">
                              {((dripVolume * 20) / (dripHours * 60)).toFixed(1)} gtts/min
                            </span>
                          </div>
                          <div className="border-t border-sky-500 pt-1.5">
                            <span className="text-[9px] font-mono font-medium uppercase tracking-wider text-sky-200 block">MICROGOTAS (Y-SITE / BOMBA)</span>
                            <span className="font-display font-extrabold text-base">
                              {(dripVolume / dripHours).toFixed(1)} mL/h
                            </span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Tool 2: Wallace Burn Regla Selection */}
                    {pwaActiveTab === "wallace" && (
                      <div className="space-y-4">
                        <p className="text-[10px] text-slate-500 leading-normal text-center">
                          Marque los segmentos afectados del paciente para estimación inmediata de SCTQ y volumen de líquidos.
                        </p>

                        <div className="grid grid-cols-2 gap-1.5">
                          <button
                            onClick={() => setWallaceSelected(prev => ({ ...prev, cabeza: !prev.cabeza }))}
                            className={`p-2 rounded-lg border text-xs font-semibold ${wallaceSelected.cabeza ? "bg-red-500 text-white border-red-500" : "bg-white border-slate-100 text-slate-700"}`}
                          >
                            Cabeza/Cuello (9%)
                          </button>
                          <button
                            onClick={() => setWallaceSelected(prev => ({ ...prev, troncoAnt: !prev.troncoAnt }))}
                            className={`p-2 rounded-lg border text-xs font-semibold ${wallaceSelected.troncoAnt ? "bg-red-500 text-white border-red-500" : "bg-white border-slate-100 text-slate-700"}`}
                          >
                            Pecho/Abdomen (18%)
                          </button>
                          <button
                            onClick={() => setWallaceSelected(prev => ({ ...prev, troncoPost: !prev.troncoPost }))}
                            className={`p-2 rounded-lg border text-xs font-semibold ${wallaceSelected.troncoPost ? "bg-red-500 text-white border-red-500" : "bg-white border-slate-100 text-slate-700"}`}
                          >
                            Espalda completa (18%)
                          </button>
                          <button
                            onClick={() => setWallaceSelected(prev => ({ ...prev, brazoIzq: !prev.brazoIzq }))}
                            className={`p-2 rounded-lg border text-xs font-semibold ${wallaceSelected.brazoIzq ? "bg-red-500 text-white border-red-500" : "bg-white border-slate-100 text-slate-700"}`}
                          >
                            Brazo Izq (9%)
                          </button>
                          <button
                            onClick={() => setWallaceSelected(prev => ({ ...prev, brazoDer: !prev.brazoDer }))}
                            className={`p-2 rounded-lg border text-xs font-semibold ${wallaceSelected.brazoDer ? "bg-red-500 text-white border-red-500" : "bg-white border-slate-100 text-slate-700"}`}
                          >
                            Brazo Der (9%)
                          </button>
                          <button
                            onClick={() => setWallaceSelected(prev => ({ ...prev, piernaIzq: !prev.piernaIzq }))}
                            className={`p-2 rounded-lg border text-xs font-semibold ${wallaceSelected.piernaIzq ? "bg-red-500 text-white border-red-500" : "bg-white border-slate-100 text-slate-700"}`}
                          >
                            Pierna Izq (18%)
                          </button>
                          <button
                            onClick={() => setWallaceSelected(prev => ({ ...prev, piernaDer: !prev.piernaDer }))}
                            className={`p-2 rounded-lg border text-xs font-semibold ${wallaceSelected.piernaDer ? "bg-red-500 text-white border-red-500" : "bg-white border-slate-100 text-slate-700"}`}
                          >
                            Pierna Der (18%)
                          </button>
                          <button
                            onClick={() => setWallaceSelected(prev => ({ ...prev, genitales: !prev.genitales }))}
                            className={`p-2 rounded-lg border text-xs font-semibold ${wallaceSelected.genitales ? "bg-red-500 text-white border-red-500" : "bg-white border-slate-100 text-slate-700"}`}
                          >
                            Genitales (1%)
                          </button>
                        </div>

                        {/* Reset body button */}
                        <button 
                          onClick={() => setWallaceSelected({
                            cabeza: false, troncoAnt: false, troncoPost: false,
                            brazoIzq: false, brazoDer: false, piernaIzq: false, piernaDer: false, genitales: false
                          })}
                          className="w-full py-1 text-[10px] text-slate-400 hover:text-slate-600 hover:underline"
                        >
                          Limpiar Selecciones
                        </button>

                        <div className="bg-red-500/10 border border-red-500/20 text-red-700 p-3 rounded-xl text-center">
                          <span className="text-[9px] font-mono font-medium uppercase tracking-wider block">SCTQ ESTIMADA</span>
                          <span className="font-display font-extrabold text-lg">{calculateTBSA()}% de Superficie</span>
                          <span className="text-[10px] text-slate-500 block mt-1">
                            Líquidos: {getParklandVolume().toLocaleString()} mL ringer-lactato / 1ªs 24h
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Tool 3: Emergency Quick dosages */}
                    {pwaActiveTab === "pautas" && (
                      <div className="space-y-2.5">
                        <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block mb-2 text-center">Filtro Rápido de Dosis Directas</span>
                        
                        <div className="space-y-2">
                          <div className="bg-white hover:bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-left">
                            <span className="text-xs font-bold text-slate-900 block">Adrenalina en PCR</span>
                            <span className="text-[10px] text-slate-500 block">1mg cada 3-5m directo en fístula/vía IV limpia.</span>
                          </div>
                          <div className="bg-white hover:bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-left">
                            <span className="text-xs font-bold text-slate-900 block">Amiodarona en Ritmos DF</span>
                            <span className="text-[10px] text-slate-500 block">300mg tras el 3er choque diluida en SG 5% bolus.</span>
                          </div>
                          <div className="bg-white hover:bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-left">
                            <span className="text-xs font-bold text-slate-900 block">Sulfato de Magnesio</span>
                            <span className="text-[10px] text-slate-500 block">Torsión de puntas: 1.5 - 2g IV en 100 mL de SG5% en 15m.</span>
                          </div>
                        </div>

                        <p className="text-[9px] text-center text-slate-400 italic leading-snug mt-4">
                          Las dosis mostradas son recordatorios generales de guías ERC oficiales.
                        </p>
                      </div>
                    )}

                  </div>

                  {/* Phone Footer Brand Info */}
                  <div className="bg-slate-900 text-white p-3.5 text-center text-[10px] font-mono tracking-wider flex items-center justify-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-sky-400" />
                    <span>APP CON ACCESO DIRECTO</span>
                  </div>

                </div>

              </div>
            </div>

          </div>

        </div>
      </section>


      {/* SECTION RECURSOS (MANUALES, PROTOCOLOS Y GUÍAS) */}
      <section id="recursos" className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section banner */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold tracking-widest text-sky-600 uppercase">BIBLIOTECA EN DESCARGA</span>
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 mt-2 tracking-tight">
              Recursos Clínicos Gratis y Basados en Evidencia
            </h2>
            <p className="text-md text-slate-600 mt-4 leading-relaxed">
              Consigue mis manuales resumidos, guías de práctica clínica y protocolos rápidos de bolsillo. Clasificados por competencia para darte exactamente la información que requieres.
            </p>

            {/* Filter Tabs */}
            <div className="flex flex-wrap justify-center gap-2 mt-8">
              <button
                onClick={() => setActiveResourceCategory("todos")}
                className={`px-5 py-2 rounded-xl text-xs font-bold transition-all ${activeResourceCategory === "todos" ? "bg-sky-600 text-white shadow-sm" : "bg-slate-50 text-slate-600 hover:bg-slate-100"}`}
              >
                Todos los recursos
              </button>
              <button
                onClick={() => setActiveResourceCategory("profesional")}
                className={`px-5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${activeResourceCategory === "profesional" ? "bg-sky-600 text-white shadow-sm" : "bg-slate-50 text-slate-600 hover:bg-slate-100"}`}
              >
                <Stethoscope className="w-3.5 h-3.5" />
                Para Profesionales Sanitarios
              </button>
              <button
                onClick={() => setActiveResourceCategory("cuidador")}
                className={`px-5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${activeResourceCategory === "cuidador" ? "bg-sky-600 text-white shadow-sm" : "bg-slate-50 text-slate-600 hover:bg-slate-100"}`}
              >
                <User className="w-3.5 h-3.5" />
                Para Cuidadores y Familias
              </button>
            </div>

          </div>

          {/* Resources Grid Card Selection */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredResources.map((resource) => (
              <div 
                key={resource.id}
                className="bg-white rounded-3xl p-6 border border-slate-200/60 shadow-sm hover:shadow-lg hover:border-sky-100 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  
                  {/* Category & Badge */}
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <span className={`text-[10px] uppercase tracking-wider font-bold px-2.5 py-1 rounded-md ${resource.category === "profesional" ? "bg-sky-50 text-sky-700 border border-sky-100/60" : "bg-teal-50 text-teal-700 border border-teal-100/60"}`}>
                      {resource.category === "profesional" ? "Profesional" : "Cuidador"}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-400 font-mono">
                      {resource.downloadSize}
                    </span>
                  </div>

                  <h3 className="font-display font-bold text-lg text-slate-900 mb-2 leading-snug hover:text-sky-600 transition-colors">
                    {resource.title}
                  </h3>
                  
                  <p className="text-xs text-slate-500 leading-relaxed mb-6">
                    {resource.description}
                  </p>

                </div>

                <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
                  {resource.duration && (
                    <span className="text-[11px] text-slate-400 font-medium">
                      Dimensión: {resource.duration}
                    </span>
                  )}
                  <button
                    onClick={() => setSelectedResource(resource)}
                    className="inline-flex items-center gap-1 bg-slate-50 hover:bg-sky-50 text-slate-700 hover:text-sky-700 text-xs font-bold px-3 py-2 rounded-lg border border-slate-100 hover:border-sky-100 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5 text-sky-600" />
                    <span>Ver Guía / PDF</span>
                  </button>
                </div>

              </div>
            ))}
          </div>

        </div>
      </section>


      {/* SECTION BLOG (SALUD Y DEBATE CIENTÍFICO) */}
      <section id="blog" className="py-20 lg:py-28 bg-slate-50/70 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Main header title */}
          <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-4">
            <div className="max-w-2xl">
              <span className="text-xs font-bold tracking-widest text-sky-600 uppercase">DIVULGACIÓN CON EVIDENCIA</span>
              <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 mt-2 tracking-tight">
                Debates Abiertos y Educación Científica
              </h2>
              <p className="text-md text-slate-600 mt-4 leading-relaxed">
                Últimos aportes y debates sobre sanidad, desacreditando bulos corporales y analizando de manera concienzuda la gestión de nuestra salud pública en 2026.
              </p>
            </div>
            <a 
              href="https://instagram.com/elenfermerohugo" 
              target="_blank"
              className="group inline-flex items-center gap-2 bg-white hover:bg-slate-50 text-slate-800 hover:text-sky-600 font-bold text-xs px-5 py-3 rounded-xl border border-slate-200 transition-all shrink-0 shadow-sm"
            >
              <Instagram className="w-4 h-4 text-pink-500" />
              <span>Debatir en Redes</span>
              <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
            </a>
          </div>

          {/* Grid of articles */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {BLOG_POSTS.map((post) => (
              <article 
                key={post.id}
                className="bg-white rounded-3xl overflow-hidden border border-slate-200/50 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  
                  {/* Article main picture */}
                  <div className="relative h-48 bg-slate-100 overflow-hidden">
                    <img 
                      src={post.imageUrl} 
                      alt={post.title} 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    />
                    <span className="absolute top-4 left-4 bg-white/90 backdrop-blur-md text-[10px] font-bold text-slate-900 px-3 py-1 rounded-full shadow-xs border border-white/40">
                      {post.category}
                    </span>
                  </div>

                  {/* Body text details */}
                  <div className="p-6">
                    <div className="flex items-center gap-3 text-slate-400 text-[11px] mb-3">
                      <span className="font-medium flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {post.readTime}
                      </span>
                      <span>•</span>
                      <span className="font-medium">{post.date}</span>
                    </div>

                    <h3 className="font-display font-extrabold text-lg text-slate-950 mb-3 hover:text-sky-600 transition-colors leading-snug">
                      {post.title}
                    </h3>

                    <p className="text-xs text-slate-500 leading-relaxed">
                      {post.excerpt}
                    </p>
                  </div>

                </div>

                <div className="px-6 pb-6 pt-4 border-t border-slate-50 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-sky-100 flex items-center justify-center text-sky-600 text-[9px] font-bold">
                      EH
                    </div>
                    <span className="text-[11px] font-semibold text-slate-700">Por {post.author}</span>
                  </div>
                  <button
                    onClick={() => setSelectedPost(post)}
                    className="inline-flex items-center gap-1 text-sky-600 hover:text-sky-500 text-xs font-bold transition-colors cursor-pointer"
                  >
                    <span>Leer Artículo</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

              </article>
            ))}
          </div>

        </div>
      </section>


      {/* SECTION TIENDA (MERCHANDISING Y INSTRUMENTAL) */}
      <section id="tienda" className="py-20 lg:py-28 bg-white border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Title description with quick dynamic shopping cart notice */}
          <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-4">
            <div className="max-w-2xl">
              <span className="text-xs font-bold tracking-widest text-sky-600 uppercase">RECOMENDADO POR HUGO</span>
              <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 mt-2 tracking-tight">
                El Escaparate de Enfermería
              </h2>
              <p className="text-md text-slate-600 mt-4 leading-relaxed">
                Una meticulosa selección de productos e instrumental que me acompañan en mis guardias de hospital diaria, diseñados para agilizar el trabajo clínico u ofrecer inspiración.
              </p>
            </div>
            <div className="flex items-center gap-2 bg-sky-50 border border-sky-100/50 p-2 rounded-xl shrink-0">
              <div className="w-2.5 h-2.5 rounded-full bg-sky-500 animate-pulse" />
              <span className="text-xs font-semibold text-sky-700">Garantía clínica de calidad</span>
            </div>
          </div>

          {/* Shop Items Quad Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {PRODUCTS.map((product) => (
              <div 
                key={product.id}
                className="bg-white rounded-3xl overflow-hidden border border-slate-200/50 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  
                  {/* Photo with inline rating hover badge */}
                  <div className="relative h-48 bg-slate-100 overflow-hidden flex items-center justify-center">
                    <img 
                      src={product.imageUrl} 
                      alt={product.title} 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-xs px-2 py-1 rounded-lg text-[10px] font-bold text-amber-500 flex items-center gap-1 shadow-xs border border-white/40">
                      <Star className="w-3 h-3 fill-amber-500" />
                      <span>{product.rating}</span>
                    </div>
                  </div>

                  <div className="p-5">
                    
                    {/* Category Label */}
                    <span className="text-[9px] font-bold text-sky-600 font-mono tracking-widest uppercase mb-1 block">
                      {product.category}
                    </span>

                    <h3 className="font-sans font-bold text-slate-950 text-sm mb-2 hover:text-sky-600 transition-colors line-clamp-1">
                      {product.title}
                    </h3>

                    <p className="text-[11px] text-slate-500 hover:text-slate-800 transition-colors line-clamp-2 leading-relaxed mb-4">
                      {product.description}
                    </p>

                    {/* Compact Product Bullet Points */}
                    <ul className="space-y-1 mb-2">
                      {product.features.slice(0, 2).map((feat, idx) => (
                        <li key={idx} className="text-[10px] text-slate-400 flex items-center gap-1">
                          <Check className="w-3 h-3 text-sky-500 shrink-0" />
                          <span className="truncate">{feat}</span>
                        </li>
                      ))}
                    </ul>

                  </div>

                </div>

                {/* Pricing & Cart Action Trigger */}
                <div className="p-5 pt-0">
                  <div className="border-t border-slate-50 pt-3.5 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-400 block leading-none">Precio</span>
                      <span className="font-display font-extrabold text-base text-slate-950 mt-1 block">
                        {product.price.toFixed(2)}€
                      </span>
                    </div>
                    <button
                      onClick={() => addToCart(product)}
                      className="bg-slate-900 hover:bg-sky-600 text-white font-bold text-[11px] px-3.5 py-2.5 rounded-xl transition shadow-xs flex items-center gap-1 text-xs cursor-pointer"
                    >
                      <ShoppingBag className="w-3.5 h-3.5 text-sky-300" />
                      <span>Añadir</span>
                    </button>
                  </div>
                </div>

              </div>
            ))}
          </div>

        </div>
      </section>


      {/* COMMUNITY SECTION (INSTAGRAM SHOWCASE) */}
      <section id="comunidad" className="py-20 lg:py-28 bg-[#EBF4F6]/50 border-t border-sky-100/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Centered card header with social stats */}
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-bold tracking-widest text-pink-600 uppercase flex items-center justify-center gap-1.5">
              <Instagram className="w-4 h-4" /> COMUNIDAD DIGITAL
            </span>
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-slate-900 mt-2 tracking-tight">
              Sigue el pulso en @elenfermerohugo
            </h2>
            <p className="text-md text-slate-600 mt-3 leading-relaxed">
              Únete a miles de profesionales de la salud y pacientes que consultan diariamente mis infografías, aclaraciones y vídeos sobre cómo cuidar mejor.
            </p>

            {/* Simulated live counters */}
            <div className="flex justify-center gap-6 mt-6">
              <div className="bg-white px-4 py-2.5 rounded-2xl border border-slate-100 shadow-xs">
                <span className="font-display font-black text-slate-950 block text-lg">{INSTAGRAM_FEED_PREVIEW.followers}</span>
                <span className="text-[10px] text-slate-400 font-medium">Seguidores</span>
              </div>
              <div className="bg-white px-4 py-2.5 rounded-2xl border border-slate-100 shadow-xs">
                <span className="font-display font-black text-slate-950 block text-lg">{INSTAGRAM_FEED_PREVIEW.postsCount}</span>
                <span className="text-[10px] text-slate-400 font-medium">Posteos</span>
              </div>
            </div>
          </div>

          {/* Simulated Instagram Grid Gallery */}
          <div className="grid sm:grid-cols-3 gap-8">
            {INSTAGRAM_FEED_PREVIEW.posts.map((post) => (
              <a 
                href={INSTAGRAM_FEED_PREVIEW.profileUrl}
                target="_blank"
                key={post.id}
                className="group bg-white rounded-3xl overflow-hidden border border-slate-200/50 shadow-xs hover:shadow-lg transition-all duration-300 block"
              >
                
                {/* Photo space */}
                <div className="relative h-60 overflow-hidden bg-slate-100">
                  <img 
                    src={post.imageUrl} 
                    alt="Instagram Post" 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-102 transition duration-500"
                  />
                  {/* Overlay metrics on profile hover */}
                  <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-6 text-white font-bold text-sm">
                    <span className="flex items-center gap-1.5 hover:scale-105 transition-transform"><Heart className="w-5 h-5 fill-white" /> {post.likes}</span>
                    <span className="flex items-center gap-1.5 hover:scale-105 transition-transform"><MessageCircle className="w-5 h-5 fill-white" /> {post.comments}</span>
                  </div>
                </div>

                {/* Sub text caption preview */}
                <div className="p-5 bg-white">
                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {post.caption}
                  </p>
                  <div className="mt-4 flex items-center gap-1.5 text-[11px] font-bold text-pink-600">
                    <Instagram className="w-3.5 h-3.5" />
                    <span>Ver publicación original</span>
                  </div>
                </div>

              </a>
            ))}
          </div>

          {/* Action Box to subscribe */}
          <div className="mt-16 max-w-4xl mx-auto rounded-3xl bg-slate-950 text-white p-8 lg:p-12 relative overflow-hidden shadow-xl">
            <div className="absolute -right-12 -bottom-12 w-48 h-48 bg-sky-500/20 rounded-full blur-2xl" />
            
            <div className="relative z-10 grid md:grid-cols-12 gap-8 items-center">
              <div className="md:col-span-7">
                <span className="text-[10px] font-bold tracking-widest text-sky-400 uppercase">EMAIL NEWSLETTER</span>
                <h3 className="font-display font-semibold text-2xl lg:text-3xl text-white mt-1 leading-snug">
                  No te pierdas ninguna guía clínica
                </h3>
                <p className="text-xs text-sky-200 mt-2 leading-relaxed">
                  Únete y recibe de forma quincenal actualizaciones científicas, alertas PWA, trucos de oposición de enfermería y recursos sanitarios directamente en tu email.
                </p>
              </div>

              <div className="md:col-span-5 w-full">
                {newsletterSubscribed ? (
                  <div className="bg-sky-550/10 border border-sky-400/30 p-5 rounded-2xl text-center flex flex-col items-center justify-center gap-2 animate-fade-in text-white/90">
                    <Check className="w-6 h-6 text-sky-400 stroke-[3]" />
                    <span className="font-semibold text-xs">¡Te has suscrito con éxito, colegiado!</span>
                    <span className="text-[10px] text-sky-200">Enviado cupón de bienvenida e infografía de emergencias.</span>
                  </div>
                ) : (
                  <form 
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (newsletterEmail) setNewsletterSubscribed(true);
                    }}
                    className="flex flex-col sm:flex-row gap-2"
                  >
                    <input 
                      type="email" 
                      placeholder="Tu correo electrónico..."
                      required
                      value={newsletterEmail}
                      onChange={(e) => setNewsletterEmail(e.target.value)}
                      className="flex-1 bg-white/10 border border-white/10 hover:border-white/20 focus:border-sky-500 focus:outline-none p-3.5 rounded-xl text-xs placeholder:text-slate-400 transition"
                    />
                    <button
                      type="submit"
                      className="bg-sky-500 hover:bg-sky-450 text-slate-950 font-bold text-xs px-5 py-3.5 rounded-xl transition flex items-center justify-center gap-1"
                    >
                      <span>Suscribirme</span>
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>
                )}
              </div>
            </div>

          </div>

        </div>
      </section>


      {/* FOOTER & SOCIAL CONNECT */}
      <footer className="bg-slate-950 text-slate-400 pt-16 pb-12 border-t border-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid md:grid-cols-4 gap-10 pb-12 border-b border-sky-950/40">
            
            {/* Column 1 info brand */}
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center font-bold">
                  <Stethoscope className="w-4 h-4" />
                </div>
                <span className="font-display font-bold text-white text-base">Enfermero Hugo</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
                Enfermero de cuidados complejos, divulgador médico y sanitario e impulsor de aprendizaje interactivo. Construyendo contenidos de salud con total apego a la evidencia científica vigente.
              </p>
              
              {/* Profile sub branding links */}
              <div className="mt-6 flex gap-3 text-slate-400 hover:text-white transition">
                <a href="https://instagram.com/elenfermerohugo" target="_blank" className="p-2 bg-slate-900 rounded-lg hover:bg-slate-800 transition">
                  <Instagram className="w-4 h-4 text-pink-500" />
                </a>
                <a href="mailto:hugocampillomoya@gmail.com" className="p-2 bg-slate-900 rounded-lg hover:bg-slate-800 transition">
                  <Mail className="w-4 h-4 text-emerald-400" />
                </a>
              </div>
            </div>

            {/* Column 2 navigation directories */}
            <div>
              <h4 className="font-display font-semibold text-white text-xs tracking-wider uppercase mb-4">Navegar</h4>
              <ul className="space-y-2.5 text-xs">
                <li><a href="#inicio" className="hover:text-white transition">Inicio</a></li>
                <li><a href="#recursos" className="hover:text-white transition">Biblioteca PDF</a></li>
                <li><a href="#pwa" className="hover:text-white transition">La Aplicación PWA</a></li>
                <li><a href="#blog" className="hover:text-white transition">Blog Divulgativo</a></li>
                <li><a href="#tienda" className="hover:text-white transition">Escaparate</a></li>
              </ul>
            </div>

            {/* Column 3 administrative elements */}
            <div>
              <h4 className="font-display font-semibold text-white text-xs tracking-wider uppercase mb-4">Políticas Legales</h4>
              <ul className="space-y-2.5 text-xs">
                <li><span className="text-slate-500 leading-relaxed block">Los contenidos presentes en el sitio actúan únicamente con carácter educativo y divulgativo. No sustituyen nunca la consulta oficial de su médico habitual.</span></li>
                <li><a href="#" onClick={(e) => e.preventDefault()} className="hover:text-white transition">Aviso Legal</a></li>
                <li><a href="#" onClick={(e) => e.preventDefault()} className="hover:text-white transition">Política de Cookies</a></li>
              </ul>
            </div>

          </div>

          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-4">
            <span>
              &copy; {new Date().getFullYear()} Enfermero Hugo (@elenfermerohugo). Reservados todos los derechos.
            </span>
            <div className="flex gap-4">
              <span>Diseñado con rigor y base científica</span>
              <span>•</span>
              <a href="mailto:hugocampillomoya@gmail.com" className="hover:text-white transition">Soporte técnico</a>
            </div>
          </div>

        </div>
      </footer>


      {/* MODAL / DRAWER INTERACTIVE: READING SPECIFIC RESOURCE SHEETS */}
      <AnimatePresence>
        {selectedResource && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-hidden">
            
            {/* Overlay background blur */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedResource(null)}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs"
            />

            {/* Dialog sheet card */}
            <motion.div
              initial={{ scale: 0.95, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              transition={{ type: "spring", bounce: 0, duration: 0.3 }}
              className="bg-white rounded-3xl w-full max-w-3xl max-h-[85vh] flex flex-col justify-between relative shadow-2xl overflow-hidden z-10 border border-slate-100"
            >
              
              {/* Header card view */}
              <div className="p-6 bg-slate-50 border-b border-slate-100 flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-md ${selectedResource.category === "profesional" ? "bg-sky-50 text-sky-700 border" : "bg-teal-50 text-teal-700 border"}`}>
                      {selectedResource.category === "profesional" ? "Sanitario Profesional" : "Cuidado Familiar"}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono font-bold">PDF ({selectedResource.downloadSize})</span>
                  </div>
                  <h3 className="font-display font-extrabold text-xl text-slate-950 leading-tight">
                    {selectedResource.title}
                  </h3>
                </div>
                <button 
                  onClick={() => setSelectedResource(null)}
                  className="p-2 rounded-xl hover:bg-slate-200/50 text-slate-400 hover:text-slate-900 transition"
                  title="Cerrar"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Scrollable read sheet content */}
              <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6">
                
                {/* Clinical notice */}
                <div className="p-4 bg-amber-50 border border-amber-200/30 text-amber-800 rounded-2xl flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <p className="font-bold">Aviso Clínico Docente</p>
                    <p className="mt-0.5 leading-relaxed text-amber-900/80">Esta ficha resume directrices basadas en guías oficiales de simulación clínica. Compruebe siempre el protocolo local vigente antes de cualquier manipulación.</p>
                  </div>
                </div>

                {/* Simulated Markdown Body text rendering */}
                <div className="prose prose-sky prose-sm max-w-none text-slate-700">
                  <div className="whitespace-pre-line text-xs leading-relaxed font-sans space-y-4">
                    {selectedResource.contentMarkdown.split("\n\n").map((chunk, index) => {
                      if (chunk.trim().startsWith("#")) {
                        return <h4 key={index} className="font-display font-extrabold text-slate-950 text-base mt-4 block">{chunk.replace(/#/g, "").trim()}</h4>;
                      }
                      if (chunk.trim().startsWith("*") || chunk.trim().startsWith("-")) {
                        return (
                          <ul key={index} className="list-disc pl-5 space-y-2 mt-2">
                            {chunk.split("\n").map((li, i) => (
                              <li key={i}>{li.replace(/^[*\-]\s*/, "").trim()}</li>
                            ))}
                          </ul>
                        );
                      }
                      return <p key={index} className="text-xs text-slate-600 leading-relaxed mt-2">{chunk.trim()}</p>;
                    })}
                  </div>
                </div>

              </div>

              {/* Footer action */}
              <div className="p-6 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-xs text-slate-500 font-medium">
                  Documento redactado y validado por <strong>Hugo M. (@elenfermerohugo)</strong>
                </div>
                <button
                  onClick={() => {
                    // Simulate beautiful download trigger
                    alert(`✅ ¡Excelente elección! Se ha descargado el archivo "${selectedResource.title}.pdf" (${selectedResource.downloadSize}) satisfactoriamente.`);
                    setSelectedResource(null);
                  }}
                  className="w-full sm:w-auto bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs px-6 py-3 rounded-xl transition shadow-md flex items-center justify-center gap-1.5 cursor-pointer animate-pulse"
                >
                  <Download className="w-4 h-4" />
                  <span>Confirmar Descarga de PDF</span>
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>


      {/* MODAL / DRAWER INTERACTIVE: READING SPECIFIC BLOG POST */}
      <AnimatePresence>
        {selectedPost && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-hidden">
            
            {/* Background Blur Overlay shadow */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedPost(null)}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs"
            />

            {/* Big article dashboard card */}
            <motion.div
              initial={{ scale: 0.95, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              transition={{ type: "spring", bounce: 0, duration: 0.3 }}
              className="bg-white rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col justify-between relative shadow-2xl overflow-hidden z-10 border border-slate-100"
            >
              
              {/* Close Button top floating */}
              <button 
                onClick={() => setSelectedPost(null)}
                className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-slate-950/50 hover:bg-slate-950 text-white transition shadow-sm"
                title="Cerrar artículo"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Dynamic Header Wallpaper with subtle title gradient card overlay */}
              <div className="relative h-60 w-full shrink-0">
                <img 
                  src={selectedPost.imageUrl} 
                  alt={selectedPost.title} 
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/50 to-transparent" />
                
                {/* Content Overlay */}
                <div className="absolute bottom-6 left-6 right-6 text-white text-left">
                  <span className="text-[10px] font-bold uppercase tracking-widest bg-sky-600 px-2.5 py-1 rounded-md mb-2 inline-block">
                    {selectedPost.category}
                  </span>
                  <h3 className="font-display font-extrabold text-xl sm:text-2xl text-white mt-1 leading-snug tracking-tight">
                    {selectedPost.title}
                  </h3>
                </div>
              </div>

              {/* Article content scroll */}
              <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6">
                
                {/* Metadata details panel */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center font-bold text-xs">
                      EH
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-950 leading-tight">Por {selectedPost.author}</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">Enfermero Clínico y Divulgador</p>
                    </div>
                  </div>
                  <div className="text-[11px] text-slate-400 font-medium text-right">
                    <p>{selectedPost.date}</p>
                    <p className="mt-0.5">{selectedPost.readTime}</p>
                  </div>
                </div>

                {/* Subtitle / Excerpt bold introduction */}
                <p className="text-slate-900 font-medium text-xs leading-relaxed border-l-4 border-sky-500 pl-4 py-1 italic bg-slate-50">
                  {selectedPost.excerpt}
                </p>

                {/* Actual article text rendering */}
                <div className="prose prose-sky prose-sm max-w-none text-slate-700 leading-relaxed font-sans space-y-4">
                  {selectedPost.content.split("\n\n").map((p, index) => {
                    const text = p.trim();
                    if (text.startsWith("###")) {
                      return <h4 key={index} className="font-display font-bold text-slate-900 text-base mt-2">{text.replace(/###/g, "").trim()}</h4>;
                    }
                    if (text.startsWith("1.") || text.startsWith("2.") || text.startsWith("3.")) {
                      return (
                        <div key={index} className="space-y-1 pl-4 border-l-2 border-slate-100">
                          {text.split("\n").map((line, i) => (
                            <p key={i} className="text-xs text-slate-600">{line.trim()}</p>
                          ))}
                        </div>
                      );
                    }
                    return <p key={index} className="text-xs text-slate-600 whitespace-pre-line">{text}</p>;
                  })}
                </div>

              </div>

              {/* Share actions */}
              <div className="p-6 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-xs text-slate-500 font-medium">
                  ¿Te ha resultado útil? Comparte con rigor científico.
                </div>
                <div className="flex gap-2 w-full sm:w-auto">
                  <a 
                    href="https://instagram.com/elenfermerohugo"
                    target="_blank"
                    className="flex-1 sm:flex-initial bg-slate-950 text-white font-bold text-xs px-5 py-3 rounded-xl hover:bg-slate-800 transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Instagram className="w-3.5 h-3.5 text-pink-500" />
                    <span>Debatir en Instagram</span>
                  </a>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`${window.location.href}#blog/${selectedPost.id}`);
                      alert("🔗 ¡Enlace del artículo copiado al portapapeles con éxito!");
                    }}
                    className="p-3 bg-white hover:bg-slate-100 rounded-xl border border-slate-200 text-slate-700 transition"
                    title="Copiar Enlace"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>


      {/* INTERACTIVE SIDEBAR: SHOPPING CART SLIDE OVER PANEL */}
      <AnimatePresence>
        {cartOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden">
            
            {/* Backdrop opacity sheet */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setCartOpen(false)}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs"
            />

            {/* Sidebar shelf container */}
            <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
              <motion.div
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "spring", bounce: 0, duration: 0.35 }}
                className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between"
              >
                
                {/* Header title */}
                <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShoppingBag className="w-5 h-5 text-sky-600" />
                    <span className="font-display font-extrabold text-slate-900 text-base">Tu Pedido</span>
                    <span className="bg-sky-50 text-sky-700 text-xs font-bold px-2.5 py-0.5 rounded-full">
                      {cartItemCount}
                    </span>
                  </div>
                  <button 
                    onClick={() => setCartOpen(false)}
                    className="p-2 -mr-2 rounded-lg hover:bg-slate-50 text-slate-400 hover:text-slate-950 transition"
                    title="Cerrar panel"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Items scroll section */}
                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  {cart.length === 0 ? (
                    <div className="text-center py-16 text-slate-400 space-y-3">
                      <ShoppingBag className="w-12 h-12 stroke-[1] text-slate-350 mx-auto" />
                      <div>
                        <p className="font-bold text-sm text-slate-600">Tu cesta está vacía</p>
                        <p className="text-xs text-slate-400 mt-1 leading-normal max-w-xs mx-auto">Revisa el Escaparate de Enfermería para añadir algún fonendo u organizador salvador.</p>
                      </div>
                      <button
                        onClick={() => setCartOpen(false)}
                        className="mt-4 inline-flex items-center gap-1.5 bg-slate-100 hover:bg-sky-50 text-slate-800 hover:text-sky-700 font-bold text-xs px-4 py-2.5 rounded-xl transition"
                      >
                        Ir a Escaparate
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {cart.map((item) => (
                        <div 
                          key={item.product.id}
                          className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100 relative group animate-fade-in"
                        >
                          {/* Image box */}
                          <div className="w-16 h-16 rounded-xl bg-white overflow-hidden border border-slate-200/50 flex items-center justify-center shrink-0">
                            <img src={item.product.imageUrl} alt={item.product.title} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                          </div>

                          {/* Details */}
                          <div className="flex-1 min-w-0">
                            <span className="text-[9px] uppercase font-bold text-sky-600 font-mono block leading-none">{item.product.category}</span>
                            <h4 className="font-sans font-bold text-slate-950 text-xs mt-1 truncate">{item.product.title}</h4>
                            <p className="font-bold text-slate-950 text-xs mt-1">{(item.product.price * item.quantity).toFixed(2)}€</p>
                            
                            {/* Quantity controls */}
                            <div className="flex items-center gap-2.5 mt-2">
                              <span className="text-[10px] text-slate-500 font-medium">Uds:</span>
                              <div className="flex items-center gap-1">
                                <button 
                                  onClick={() => updateQuantity(item.product.id, -1)}
                                  className="w-5.5 h-5.5 bg-white border border-slate-200 hover:bg-slate-150 rounded-md text-xs font-bold flex items-center justify-center text-slate-600 transition"
                                >
                                  -
                                </button>
                                <span className="text-xs text-slate-950 font-extrabold w-5 text-center">{item.quantity}</span>
                                <button 
                                  onClick={() => updateQuantity(item.product.id, 1)}
                                  className="w-5.5 h-5.5 bg-white border border-slate-200 hover:bg-slate-150 rounded-md text-xs font-bold flex items-center justify-center text-slate-600 transition"
                                >
                                  +
                                </button>
                              </div>
                            </div>
                          </div>

                          {/* Absolute Delete Button */}
                          <button
                            onClick={() => removeFromCart(item.product.id)}
                            className="absolute top-4 right-4 text-slate-400 hover:text-red-500 p-1 rounded-md hover:bg-red-50 transition"
                            title="Quitar artículo"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>

                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Bottom billing info checkout summary */}
                {cart.length > 0 && (
                  <div className="p-6 bg-slate-50 border-t border-slate-100 space-y-4">
                    
                    <div className="space-y-2 text-xs text-slate-600">
                      <div className="flex justify-between">
                        <span>Subtotal de instrumental</span>
                        <span className="font-medium text-slate-950">{cartTotal.toFixed(2)}€</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Envío Express a centro de salud</span>
                        <span className="font-medium text-slate-950 text-emerald-600">¡GRATIS para sanitarios!</span>
                      </div>
                      <div className="border-t border-slate-200 pt-3 flex justify-between text-sm font-bold text-slate-950">
                        <span>Total estimado</span>
                        <span>{cartTotal.toFixed(2)}€</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        // Secure shopping simulation
                        alert(`🛍️ ¡Tu pedido de ${cartItemCount} artículos ha sido preprocesado con éxito! Se ha enviado un enlace de pasarela simulada segura al portal de @elenfermerohugo.`);
                        setCart([]);
                        setCartOpen(false);
                      }}
                      className="w-full py-3.5 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase rounded-xl transition shadow-md flex items-center justify-center gap-2 hover:-translate-y-0.5 cursor-pointer"
                    >
                      <span>Finalizar Compra Segura</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                    <p className="text-[10px] text-slate-400 text-center leading-normal">
                      Pago seguro certificado SSL de 256 bits. Devoluciones garantizadas 30 días.
                    </p>

                  </div>
                )}

              </motion.div>
            </div>

          </div>
        )}
      </AnimatePresence>


      {/* PWA INSTALLATION INTERACTIVE MODAL TUTORIALS */}
      <AnimatePresence>
        {pwaInstallModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-hidden">
            
            {/* Opacity cover backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setPwaInstallModal(null)}
              className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs"
            />

            {/* Dial sheet card */}
            <motion.div
              initial={{ scale: 0.95, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              transition={{ type: "spring", bounce: 0, duration: 0.3 }}
              className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden relative z-10 p-6 border border-slate-100"
            >
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-sky-650" />
                  <span className="font-display font-extrabold text-slate-950 text-base">Instalar PWA Clínico</span>
                </div>
                <button 
                  onClick={() => setPwaInstallModal(null)}
                  className="p-1.5 -mr-1.5 rounded-lg hover:bg-slate-50 text-slate-400 hover:text-slate-900"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {pwaInstallModal === "ios" ? (
                /* iOS Installation Guide */
                <div className="space-y-4">
                  <div className="bg-sky-50 text-sky-850 p-4 rounded-2xl border border-sky-100 text-xs leading-normal">
                    <p className="font-bold">Para iPhone / iPad (Safari):</p>
                    <p className="mt-1">Apple no permite la instalación automática en un clic, pero puedes añadirla en 3 segundos siguiendo este procedimiento nativo:</p>
                  </div>

                  <ol className="space-y-3.5 text-xs text-slate-600">
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0">1</span>
                      <span>Abre esta misma web usando tu navegador oficial <strong>Safari</strong>.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0">2</span>
                      <span>Pulsa el icono de <strong>Compartir</strong> (un cuadrado con una flecha hacia arriba) en el menú central inferior de tu pantalla.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0">3</span>
                      <span>Desplázate hacia abajo por el menú y selecciona <strong>&quot;Añadir a pantalla de inicio&quot;</strong>.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0">4</span>
                      <span>Confirma pulsando <strong>Añadir</strong> arriba a la derecha. ¡Listo! Tendrás el icono directo como app.</span>
                    </li>
                  </ol>
                </div>
              ) : (
                /* Android Installation Guide */
                <div className="space-y-4">
                  <div className="bg-sky-50 text-sky-850 p-4 rounded-2xl border border-sky-100 text-xs leading-normal">
                    <p className="font-bold font-display">Para Android (Chrome / Edge):</p>
                    <p className="mt-1">Android proporciona instalación directa en un clic para aplicaciones web progresivas certificadas:</p>
                  </div>

                  <ol className="space-y-3.5 text-xs text-slate-600">
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0">1</span>
                      <span>Abre esta web en <strong>Google Chrome</strong> en tu móvil.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0">2</span>
                      <span>Pulsa el banner automático que suele aparecer en el pie o pulsa en los 3 puntos de configuración superiores.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0">3</span>
                      <span>Selecciona la opción <strong>&quot;Instalar Aplicación&quot;</strong> o <strong>&quot;Añadir a pantalla de inicio&quot;</strong>.</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0">4</span>
                      <span>Acepta el diálogo emergente para finalizar la instalación automatizada instantánea.</span>
                    </li>
                  </ol>
                </div>
              )}

              <button
                onClick={() => setPwaInstallModal(null)}
                className="w-full mt-7 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition uppercase tracking-wider cursor-pointer"
              >
                Entendido
              </button>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
